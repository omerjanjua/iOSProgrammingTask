//
//  IndividualBookViewController.m
//  iOSProgrammingTask
//
//  Created by Omer Janjua on 24/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "IndividualBookViewController.h"
#import "BookViewController.h"
#import "EditBookViewController.h"

@interface IndividualBookViewController ()

-(void) setupPage;
-(void) setupBooks;
-(void)setupInitialBookValues;
-(void)setupNav;
-(void)setValueForBooks;

@end

@implementation IndividualBookViewController
@synthesize scrollView;
@synthesize contentView;
@synthesize nameLabel;
@synthesize nameValue;
@synthesize priceLabel;
@synthesize priceValue;
@synthesize releaseLabel;
@synthesize releaseValue;
@synthesize authorLabel;
@synthesize authorValue;
@synthesize publisherLabel;
@synthesize publisherValue;
@synthesize reviewLabel;
@synthesize reviewValue;
@synthesize book = _book;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - setupView

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupPage];
    [self setupBooks];
    [self setupNav];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setupContent];
    [self setupBooks];
}

#pragma mark - Save
-(IBAction)savePressed:(id)sender
{
    [self setValueForBooks];
    NSString *validate = [self validateBooks];
    if ([validate isEqualToString:@""]) {
        [self.book.managedObjectContext save];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Validate" message:validate delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release]; 
        alert = nil;
    }
}

#pragma mark - Delete
-(void)bookDeleted
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - setup

-(void) setupPage
{
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelPressed:)];
    self.navigationItem.leftBarButtonItem = cancelButton;
    [cancelButton release];
    cancelButton = nil;
}

-(void) setupBooks
{
    if (!self.book) {
        Book *book = [Book createEntity];
        self.book = book;
        [self setupInitialBookValues];
    }
    
    self.nameValue.text = self.book.name;
    //self.priceValue.text = self.book.price;
    // self.releaseValue.text = self.book.releaseDate;
    self.authorValue.text = self.book.authors;
    self.publisherValue.text = self.book.publishers;
    self.reviewValue.text = self.book.reviews;
    
    NSDateFormatter *currentDate = [[NSDateFormatter alloc] init];
    [currentDate setDateFormat:@"dd-MM-yyyy"];
    NSString *stringFromDate = [currentDate stringFromDate:self.book.releaseDate];
    self.releaseValue.text = stringFromDate;
    
    NSNumberFormatter *numberformatter = [[NSNumberFormatter alloc] init];
    [numberformatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *string = [[NSString alloc] initWithFormat:@"%@", [numberformatter stringFromNumber:self.book.price]];
    self.priceValue.text = string;
    
}

-(void)setupContent
{
#warning TODO
}

-(void)setupInitialBookValues
{
    self.book.name = @"";
    //    self.book.price = @"";
    //    self.book.releaseDate = @"";
    self.book.authors = @"";
    self.book.publishers = @"";
    self.book.reviews = @"";
    
    NSDateFormatter *currentDate = [[NSDateFormatter alloc] init];
    [currentDate setDateFormat:@"dd-MM-yyyy"];
    NSString *stringFromDate = [currentDate stringFromDate:self.book.releaseDate];
    stringFromDate = @"";
    
    NSNumberFormatter *numberformatter = [[NSNumberFormatter alloc] init];
    [numberformatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *string = [[NSString alloc] initWithFormat:@"%@", [numberformatter stringFromNumber:self.book.price]];
    string = @"";
    
}

#pragma mark - edit

-(void)setupNav
{
    self.navigationItem.backBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:nil action:nil] autorelease];
    UIBarButtonItem *button = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editButtonPressed:)]autorelease];
    self.navigationItem.rightBarButtonItem = button;
}

-(IBAction)editButtonPressed:(id)sender
{
    EditBookViewController *controller = [[[EditBookViewController alloc] initWithNibName:@"EditBookView" bundle:nil]autorelease];
    controller.book = self.book;
    controller.deleteDelegate = self;
    
    
    UINavigationController *navController = [[[UINavigationController alloc] initWithRootViewController:controller]autorelease];
    [self.navigationController presentModalViewController:navController animated:YES];
}

#pragma mark - setup book values

-(void)setValueForBooks
{
    self.book.name = self.nameValue.text;
    //self.book.price = self.priceValue.text;
    //self.book.releaseDate = self.releaseValue.text;
    self.book.authors = self.authorValue.text;
    self.book.publishers = self.publisherValue.text;
    self.book.reviews = self.reviewValue.text;
    
#warning TODO ordering reverse
    NSDateFormatter *currentDate = [[NSDateFormatter alloc] init];
    [currentDate setDateFormat:@"dd-MM-yyyy"];
    NSString *stringFromDate = [currentDate stringFromDate:self.book.releaseDate];
    self.releaseValue.text = stringFromDate;
    
    NSNumberFormatter *numberformatter = [[NSNumberFormatter alloc] init];
    [numberformatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *string = [[NSString alloc] initWithFormat:@"%@", [numberformatter stringFromNumber:self.book.price]];
    self.priceValue.text = string;
}

#pragma mark - Validate

-(NSString*)validateBooks
{
    if (([self.book.name isEqualToString:@""]) && ([self.book.authors isEqualToString:@""]) && ([self.book.publishers isEqualToString:@""])) {
        return @"can you must enter a title, author and publisher please";
    }
    return @"";
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([alertView.title isEqualToString:@""]) {
        if (buttonIndex == 1) {
            [self.book deleteEntity];
        }
    }
    else {
        
    }
}


#pragma mark - dealloc and unload

- (void)viewDidUnload
{
    [self setScrollView:nil];
    [self setContentView:nil];
    [self setNameLabel:nil];
    [self setNameValue:nil];
    [self setPriceLabel:nil];
    [self setPriceValue:nil];
    [self setReleaseLabel:nil];
    [self setReleaseValue:nil];
    [self setAuthorLabel:nil];
    [self setAuthorValue:nil];
    [self setPublisherLabel:nil];
    [self setPublisherValue:nil];
    [self setReviewLabel:nil];
    [self setReviewValue:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [scrollView release];
    [contentView release];
    [nameLabel release];
    [nameValue release];
    [priceLabel release];
    [priceValue release];
    [releaseLabel release];
    [releaseValue release];
    [authorLabel release];
    [authorValue release];
    [publisherLabel release];
    [publisherValue release];
    [reviewLabel release];
    [reviewValue release];
    [super dealloc];
}
@end
