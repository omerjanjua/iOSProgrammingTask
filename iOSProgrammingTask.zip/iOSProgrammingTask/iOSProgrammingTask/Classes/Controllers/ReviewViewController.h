//
//  ReviewViewController.h
//  iOSProgrammingTask
//
//  Created by Omer Janjua on 14/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReviewViewController : UITableViewController

@property (nonatomic, retain) NSArray *review;

@end
