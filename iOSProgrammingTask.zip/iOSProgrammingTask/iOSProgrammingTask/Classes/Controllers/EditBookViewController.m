//
//  EditBookViewController.m
//  iOSProgrammingTask
//
//  Created by Omer Janjua on 14/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EditBookViewController.h"

@interface EditBookViewController ()

//private methods
-(void)setupPage;
-(void)setupBooks;
-(void)setupNav;
-(void)setupInitialBookValues;
-(void)setValueForBooks;
-(void)bookDeleted;

-(NSString*)validateBooks;

@end

@implementation EditBookViewController
@synthesize scrollView;
@synthesize contentView;
@synthesize nameLabel;
@synthesize nameValue;
@synthesize priceLabel;
@synthesize priceValue;
@synthesize releaseLabel;
@synthesize releaseValue;
@synthesize authorsLabel;
@synthesize authorsValue;
@synthesize publisherLabel;
@synthesize publisherValue;
@synthesize reviewLabel;
@synthesize reviewValue;
@synthesize deleteButton;
@synthesize book = _book;
@synthesize deleteDelegate = _deleteDelegate;


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupPage];
    [self setupBooks];
    [self setupNav];
}

#pragma mark - setup

-(void) setupPage
{
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelPressed:)];
    self.navigationItem.leftBarButtonItem = cancelButton;
    [cancelButton release];
    cancelButton = nil;
    
    self.scrollView.contentSize = self.contentView.frame.size;//
}

-(IBAction)cancelPressed:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

-(void) setupBooks
{
    self.nameValue.text = self.book.name;
    //self.priceValue.text = self.book.price;
   // self.releaseValue.text = self.book.releaseDate;
    self.authorsValue.text = self.book.authors;
    self.publisherValue.text = self.book.publishers;
    self.reviewValue.text = self.book.reviews;
        
    NSDateFormatter *currentDate = [[NSDateFormatter alloc] init];
    [currentDate setDateFormat:@"dd-MM-yyyy"];
    NSString *stringFromDate = [currentDate stringFromDate:self.book.releaseDate];
    self.releaseValue.text = stringFromDate;
    
    NSNumberFormatter *numberformatter = [[NSNumberFormatter alloc] init];
    [numberformatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *string = [[NSString alloc] initWithFormat:@"%@", [numberformatter stringFromNumber:self.book.price]];
    self.priceValue.text = string;
    
}

-(void)setValueForBooks
{
    self.book.name = self.nameValue.text;
    //self.book.price = self.priceValue.text;
    //self.book.releaseDate = self.releaseValue.text;
    self.book.authors = self.authorsValue.text;
    self.book.publishers = self.publisherValue.text;
    self.book.reviews = self.reviewValue.text;
    
    #warning TODO ordering reverse
    NSDateFormatter *currentDate = [[NSDateFormatter alloc] init];
    [currentDate setDateFormat:@"dd-MM-yyyy"];
    NSString *stringFromDate = [currentDate stringFromDate:self.book.releaseDate];
    self.releaseValue.text = stringFromDate;
    
    NSNumberFormatter *numberformatter = [[NSNumberFormatter alloc] init];
    [numberformatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *string = [[NSString alloc] initWithFormat:@"%@", [numberformatter stringFromNumber:self.book.price]];
    self.priceValue.text = string;
}

-(void)setupInitialBookValues
{
    self.book.name = @"";
//    self.book.price = @"";
//    self.book.releaseDate = @"";
    self.book.authors = @"";
    self.book.publishers = @"";
    self.book.reviews = @"";
    
    NSDateFormatter *currentDate = [[NSDateFormatter alloc] init];
    [currentDate setDateFormat:@"dd-MM-yyyy"];
    NSString *stringFromDate = [currentDate stringFromDate:self.book.releaseDate];
    stringFromDate = @"";
    
    NSNumberFormatter *numberformatter = [[NSNumberFormatter alloc] init];
    [numberformatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *string = [[NSString alloc] initWithFormat:@"%@", [numberformatter stringFromNumber:self.book.price]];
    string = @"";
    
}

-(void)setupNav
{
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(savePressed:)];
    self.navigationItem.rightBarButtonItem = button;
    [button release]; button = nil;
}

- (IBAction)savePressed:(id)sender
{
    if (!self.book) {
        Book * book = [Book createEntity];
        self.book = book;
        [self setupInitialBookValues];
    }
    [self setValueForBooks];
    NSString *validate = [self validateBooks];
    if ([validate isEqualToString:@""]) {
        [self.book.managedObjectContext save];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Validate" message:validate delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release]; 
        alert = nil;
    }
}

#pragma mark - Validate

-(NSString*)validateBooks
{
    if (([self.book.name isEqualToString:@""]) && ([self.book.authors isEqualToString:@""]) && ([self.book.publishers isEqualToString:@""])) {
        return @"can you must enter a title, author and publisher please";
    }
    return @"";
}


#pragma mark - REMOVING CONTACTS
-(IBAction)removeBookSelected:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Delete Book" message:@"Are you sure" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"ok", nil];
    [alert show];
    [alert release]; 
    alert = nil;
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([alertView.title isEqualToString:@""]) {
        if (buttonIndex == 1) {
            [self.book deleteEntity];
            [self bookDeleted];
        }
    }
}

-(void)bookDeleted
{
    if ([self.deleteDelegate respondsToSelector:@selector(bookDeleted)]) {
        [self.deleteDelegate bookDeleted];
    }
}

#pragma mark - textfield first responder
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.nameValue) {
        [self.priceValue becomeFirstResponder];
    }
    else if (textField == self.priceValue) {
        [self.releaseValue becomeFirstResponder];
    }
    else if (textField == self.releaseValue) {
        [self.authorsValue becomeFirstResponder];
    }
    else if (textField == authorsValue) {
        [self.publisherValue becomeFirstResponder];
    }
    else if (textField == publisherValue) {
        [self.reviewValue becomeFirstResponder];
    }
    else {
        [textField resignFirstResponder];
    }
    [self setValueForBooks];

    return NO;
}

- (void)viewDidUnload
{
    [self setScrollView:nil];
    [self setContentView:nil];
    [self setNameLabel:nil];
    [self setNameValue:nil];
    [self setPriceLabel:nil];
    [self setPriceValue:nil];
    [self setReleaseLabel:nil];
    [self setReleaseValue:nil];
    [self setAuthorsLabel:nil];
    [self setAuthorsValue:nil];
    [self setPublisherLabel:nil];
    [self setPublisherValue:nil];
    [self setReviewLabel:nil];
    [self setReviewValue:nil];
    [self setDeleteButton:nil];
    [super viewDidUnload];
}

- (void)dealloc {
    self.book = nil;
    [scrollView release];
    [contentView release];
    [nameLabel release];
    [nameValue release];
    [priceLabel release];
    [priceValue release];
    [releaseLabel release];
    [releaseValue release];
    [authorsLabel release];
    [authorsValue release];
    [publisherLabel release];
    [publisherValue release];
    [reviewLabel release];
    [reviewValue release];
    [deleteButton release];
    [super dealloc];
}
@end
