//
//  Review.m
//  iOSProgrammingTask
//
//  Created by Omer Janjua on 24/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Review.h"
#import "Book.h"


@implementation Review

@dynamic comment;
@dynamic rating;
@dynamic title;
@dynamic bookReview;

@end
