//
//  Book.m
//  iOSProgrammingTask
//
//  Created by Omer Janjua on 24/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Book.h"
#import "Author.h"
#import "Publisher.h"
#import "Review.h"


@implementation Book

@dynamic authors;
@dynamic name;
@dynamic price;
@dynamic publishers;
@dynamic releaseDate;
@dynamic reviews;
@dynamic author;
@dynamic publisher;
@dynamic review;

@end
