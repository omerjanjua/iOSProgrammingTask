//
//  Author.m
//  iOSProgrammingTask
//
//  Created by Omer Janjua on 24/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Author.h"
#import "Book.h"


@implementation Author

@dynamic dob;
@dynamic firstName;
@dynamic surName;
@dynamic bookAuthor;

@end
